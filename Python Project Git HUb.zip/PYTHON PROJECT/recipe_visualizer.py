'''import tkinter as tk
from tkinter import ttk, messagebox
import sqlite3
import matplotlib.pyplot as plt

# ---------- DATABASE SETUP ----------
def init_db():
    conn = sqlite3.connect("recipes.db")
    cur = conn.cursor()
    cur.execute("""
        CREATE TABLE IF NOT EXISTS recipes (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            recipe_name TEXT NOT NULL,
            ingredient TEXT NOT NULL,
            calories REAL NOT NULL
        )
    """)
    conn.commit()
    conn.close()

# ---------- ADD DATA ----------
def add_entry():
    recipe = recipe_entry.get().strip()
    ingredient = ingredient_entry.get().strip()
    cal = calorie_entry.get().strip()

    if recipe == "" or ingredient == "" or cal == "":
        messagebox.showwarning("Input Error", "Please fill all fields")
        return

    try:
        cal = float(cal)
    except:
        messagebox.showerror("Invalid Input", "Calories must be a number")
        return

    conn = sqlite3.connect("recipes.db")
    cur = conn.cursor()
    cur.execute("INSERT INTO recipes (recipe_name, ingredient, calories) VALUES (?, ?, ?)",
                (recipe, ingredient, cal))
    conn.commit()
    conn.close()
    messagebox.showinfo("Success", "Ingredient added successfully")
    recipe_entry.delete(0, tk.END)
    ingredient_entry.delete(0, tk.END)
    calorie_entry.delete(0, tk.END)

# ---------- PIE CHART ----------
def show_pie_chart():
    recipe = recipe_entry.get().strip()
    if recipe == "":
        messagebox.showwarning("Select Recipe", "Enter recipe name to view chart")
        return

    conn = sqlite3.connect("recipes.db")
    cur = conn.cursor()
    cur.execute("SELECT ingredient, calories FROM recipes WHERE recipe_name = ?", (recipe,))
    data = cur.fetchall()
    conn.close()

    if not data:
        messagebox.showinfo("No Data", "No ingredients found for this recipe")
        return

    ingredients = [d[0] for d in data]
    calories = [d[1] for d in data]

    plt.figure(figsize=(5, 5))
    plt.pie(calories, labels=ingredients, autopct="%1.1f%%")
    plt.title(f"Calorie Distribution for {recipe}")
    plt.show()

# ---------- BAR CHART ----------
def show_bar_chart():
    conn = sqlite3.connect("recipes.db")
    cur = conn.cursor()
    cur.execute("""
        SELECT recipe_name, SUM(calories) 
        FROM recipes 
        GROUP BY recipe_name
    """)
    data = cur.fetchall()
    conn.close()

    if not data:
        messagebox.showinfo("No Data", "No recipes found")
        return

    recipes = [d[0] for d in data]
    total_calories = [d[1] for d in data]

    plt.figure(figsize=(6, 4))
    plt.bar(recipes, total_calories)
    plt.title("Total Calories per Recipe")
    plt.xlabel("Recipes")
    plt.ylabel("Total Calories")
    plt.show()

# ---------- GUI SETUP ----------
root = tk.Tk()
root.title("Recipe Nutrition Visualizer")
root.geometry("400x350")
root.config(bg="#F6F5F2")

ttk.Label(root, text="Recipe Name:").pack(pady=5)
recipe_entry = ttk.Entry(root, width=30)
recipe_entry.pack()

ttk.Label(root, text="Ingredient:").pack(pady=5)
ingredient_entry = ttk.Entry(root, width=30)
ingredient_entry.pack()

ttk.Label(root, text="Calories:").pack(pady=5)
calorie_entry = ttk.Entry(root, width=30)
calorie_entry.pack()

ttk.Button(root, text="Add Ingredient", command=add_entry).pack(pady=10)
ttk.Button(root, text="Show Pie Chart (for one recipe)", command=show_pie_chart).pack(pady=5)
ttk.Button(root, text="Show Bar Chart (compare recipes)", command=show_bar_chart).pack(pady=5)

init_db()
root.mainloop()

'''
import tkinter as tk
from tkinter import ttk, messagebox
import sqlite3
import matplotlib.pyplot as plt

# ---------- DATABASE SETUP ----------
def init_db():
    conn = sqlite3.connect("recipes.db")
    cur = conn.cursor()
    cur.execute("""
        CREATE TABLE IF NOT EXISTS recipes (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            recipe_name TEXT NOT NULL,
            ingredient TEXT NOT NULL,
            calories REAL NOT NULL
        )
    """)
    conn.commit()
    conn.close()

# ---------- FETCH ALL RECIPES ----------
def get_all_recipes():
    conn = sqlite3.connect("recipes.db")
    cur = conn.cursor()
    cur.execute("SELECT DISTINCT recipe_name FROM recipes")
    recipes = [row[0] for row in cur.fetchall()]
    conn.close()
    return recipes

# ---------- ADD DATA ----------
def add_entry():
    recipe = recipe_entry.get().strip()
    ingredient = ingredient_entry.get().strip()
    cal = calorie_entry.get().strip()

    if recipe == "" or ingredient == "" or cal == "":
        messagebox.showwarning("Input Error", "Please fill all fields")
        return

    try:
        cal = float(cal)
    except:
        messagebox.showerror("Invalid Input", "Calories must be a number")
        return

    conn = sqlite3.connect("recipes.db")
    cur = conn.cursor()
    cur.execute("INSERT INTO recipes (recipe_name, ingredient, calories) VALUES (?, ?, ?)",
                (recipe, ingredient, cal))
    conn.commit()
    conn.close()
    messagebox.showinfo("Success", "Ingredient added successfully")

    recipe_entry.delete(0, tk.END)
    ingredient_entry.delete(0, tk.END)
    calorie_entry.delete(0, tk.END)

    # Update dropdown and listbox
    recipe_dropdown['values'] = get_all_recipes()
    update_listbox(recipe)

# ---------- UPDATE LISTBOX & CALORIES SUMMARY ----------
def update_listbox(recipe_name):
    listbox.delete(0, tk.END)
    conn = sqlite3.connect("recipes.db")
    cur = conn.cursor()
    cur.execute("SELECT ingredient, calories FROM recipes WHERE recipe_name = ?", (recipe_name,))
    data = cur.fetchall()
    conn.close()

    total_calories = 0
    for ing, cal in data:
        total_calories += cal
        display_text = f"{ing}: {cal} kcal"
        # Color-coding
        if cal > 100:
            listbox.insert(tk.END, display_text)
            listbox.itemconfig(tk.END, fg="red")
        else:
            listbox.insert(tk.END, display_text)
            listbox.itemconfig(tk.END, fg="green")
    calories_summary.config(text=f"Total Calories: {total_calories} kcal")

# ---------- DELETE RECIPE ----------
def delete_recipe():
    recipe = recipe_dropdown.get().strip()
    if recipe == "":
        messagebox.showwarning("Select Recipe", "Please select a recipe to delete")
        return

    confirm = messagebox.askyesno("Confirm Delete", f"Are you sure you want to delete '{recipe}'?")
    if not confirm:
        return

    conn = sqlite3.connect("recipes.db")
    cur = conn.cursor()
    cur.execute("DELETE FROM recipes WHERE recipe_name = ?", (recipe,))
    conn.commit()
    conn.close()

    messagebox.showinfo("Deleted", f"Recipe '{recipe}' has been deleted")
    recipe_dropdown['values'] = get_all_recipes()
    listbox.delete(0, tk.END)
    calories_summary.config(text="Total Calories: 0 kcal")

# ---------- PIE CHART ----------
def show_pie_chart():
    recipe = recipe_dropdown.get().strip()
    if recipe == "":
        messagebox.showwarning("Select Recipe", "Select a recipe to view chart")
        return

    conn = sqlite3.connect("recipes.db")
    cur = conn.cursor()
    cur.execute("SELECT ingredient, calories FROM recipes WHERE recipe_name = ?", (recipe,))
    data = cur.fetchall()
    conn.close()

    if not data:
        messagebox.showinfo("No Data", "No ingredients found for this recipe")
        return

    ingredients = [d[0] for d in data]
    calories = [float(d[1]) for d in data]

    # Show actual calories on pie chart
    def show_calories(pct, all_vals):
        absolute = int(round(pct/100.*sum(all_vals)))
        return f"{absolute} kcal"

    plt.figure(figsize=(5,5))
    plt.pie(calories, labels=ingredients, autopct=lambda pct: show_calories(pct, calories), startangle=90)
    plt.title(f"Calorie Distribution for {recipe}")
    plt.show()

# ---------- BAR CHART ----------
def show_bar_chart():
    conn = sqlite3.connect("recipes.db")
    cur = conn.cursor()
    cur.execute("""
        SELECT recipe_name, SUM(calories) 
        FROM recipes 
        GROUP BY recipe_name
    """)
    data = cur.fetchall()
    conn.close()

    if not data:
        messagebox.showinfo("No Data", "No recipes found")
        return

    recipes = [d[0] for d in data]
    total_calories = [float(d[1]) for d in data]

    plt.figure(figsize=(6,4))
    plt.bar(recipes, total_calories, color='skyblue')
    plt.title("Total Calories per Recipe")
    plt.xlabel("Recipes")
    plt.ylabel("Total Calories")
    plt.show()

# ---------- UPDATE LISTBOX WHEN DROPDOWN CHANGES ----------
def on_recipe_select(event):
    selected_recipe = recipe_dropdown.get()
    update_listbox(selected_recipe)

# ---------- GUI SETUP ----------
root = tk.Tk()
root.title("Recipe Nutrition Visualizer")
root.geometry("500x550")
root.config(bg="#F6F5F2")

# --- Input Frame ---
input_frame = tk.Frame(root, bg="#F6F5F2")
input_frame.pack(pady=10)

ttk.Label(input_frame, text="Recipe Name:").grid(row=0, column=0, padx=5, pady=5, sticky='w')
recipe_entry = ttk.Entry(input_frame, width=30)
recipe_entry.grid(row=0, column=1, padx=5, pady=5)

ttk.Label(input_frame, text="Ingredient:").grid(row=1, column=0, padx=5, pady=5, sticky='w')
ingredient_entry = ttk.Entry(input_frame, width=30)
ingredient_entry.grid(row=1, column=1, padx=5, pady=5)

ttk.Label(input_frame, text="Calories:").grid(row=2, column=0, padx=5, pady=5, sticky='w')
calorie_entry = ttk.Entry(input_frame, width=30)
calorie_entry.grid(row=2, column=1, padx=5, pady=5)

ttk.Button(input_frame, text="Add Ingredient", command=add_entry).grid(row=3, column=0, columnspan=2, pady=10)

# --- Recipe Dropdown ---
ttk.Label(root, text="Select Recipe:").pack(pady=5)
recipe_dropdown = ttk.Combobox(root, values=get_all_recipes())
recipe_dropdown.pack(pady=5)
recipe_dropdown.bind("<<ComboboxSelected>>", on_recipe_select)

ttk.Button(root, text="Delete Selected Recipe", command=delete_recipe).pack(pady=5)

# --- Listbox Frame ---
ttk.Label(root, text="Ingredients of Recipe:").pack(anchor='w', padx=10)
listbox = tk.Listbox(root, width=50, height=8)
listbox.pack(pady=5)

# --- Calories Summary ---
calories_summary = ttk.Label(root, text="Total Calories: 0 kcal", font=("Arial", 12, "bold"))
calories_summary.pack(pady=10)

# --- Buttons Frame ---
button_frame = tk.Frame(root, bg="#F6F5F2")
button_frame.pack(pady=10)

ttk.Button(button_frame, text="Show Pie Chart", command=show_pie_chart).grid(row=0, column=0, padx=5)
ttk.Button(button_frame, text="Show Bar Chart", command=show_bar_chart).grid(row=0, column=1, padx=5)

# Initialize database
init_db()
root.mainloop()